# Bat Clock

A Gotham-themed clock app and home-screen widgets.

- Round analog dial with a glowing ring and 60 ticks, no numbers
- Hour and minute hands, and a second dot that glides around the ring
- Digital time in the middle with the date, and the Bat-Signal on top
- Tap the clock to switch 12-hour / 24-hour
- Two home-screen widgets in the same style: 2x2 and 4x4
- The screen stays on while the clock app is open (desk clock)

Build with the GitHub Actions workflow in `.github/workflows/build.yml`, or open the folder in Android Studio.
