package com.example.batclock

import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import androidx.core.graphics.PathParser
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Bat emblem as SVG path data (viewBox 200x100). */
object BatShape {
    const val PATH =
        "M99.7,30 L104,30 L107,10 L112,28 C130,22 160,22 192,30 C186,42 182,52 178,64 " +
            "C170,56 162,56 154,66 C146,58 136,60 128,72 C120,62 112,64 106,80 L99.7,94 Z " +
            "M100.3,30 L96,30 L93,10 L88,28 C70,22 40,22 8,30 C14,42 18,52 22,64 " +
            "C30,56 38,56 46,66 C54,58 64,60 72,72 C80,62 88,64 94,80 L100.3,94 Z"
}

/**
 * Gotham clock face: a glowing ring with 60 ticks (no numbers), hour and minute hands,
 * a smooth second dot running around the ring, the Bat-Signal above the centre and the
 * digital time in the middle. Redrawn every frame so the second dot moves smoothly.
 */
class ClockView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var lastKey = -1L

    /** true = 24-hour digital time, false = 12-hour with AM/PM. */
    var use24: Boolean = false
        set(v) {
            field = v
            lastKey = -1L
        }

    private val yellow = 0xFFFFD400.toInt()
    private val amber = 0xFFFFB300.toInt()
    private val white = 0xFFF2F2F2.toInt()
    private val softYellow = 0xFFFFE566.toInt()

    private val batPath: Path = PathParser.createPathFromPathData(BatShape.PATH)
    private val shapePath = Path()
    private val shapeMatrix = Matrix()
    private val ovalRect = RectF()

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val discPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = yellow; alpha = 16 }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = yellow
    }
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val handGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = yellow
        alpha = 56
    }
    private val handPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val signalGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = yellow }
    private val signalPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0A0A0F.toInt() }
    private val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        color = white
    }
    private val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        letterSpacing = 0.2f
        color = 0xFF8A8A96.toInt()
    }

    private var cx = 0f
    private var cy = 0f
    private var radius = 0f
    private var strokeW = 0f
    private var ecy = 0f
    private var erx = 0f
    private var ery = 0f

    private val cal: Calendar = Calendar.getInstance()
    private var timeText = ""
    private var dateText = ""
    private val t0 = SystemClock.uptimeMillis()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cx = w / 2f
        cy = h / 2f
        radius = min(w, h) / 2f * 0.74f
        strokeW = radius * 0.085f

        ringPaint.strokeWidth = strokeW
        tickPaint.strokeWidth = max(2f, strokeW * 0.16f)

        bgPaint.shader = RadialGradient(
            cx, cy, max(w, h) * 0.75f,
            intArrayOf(0xFF1C1C26.toInt(), 0xFF09090D.toInt()), null, Shader.TileMode.CLAMP
        )
        haloPaint.shader = RadialGradient(
            cx, cy, radius * 1.35f,
            intArrayOf(0x66FFD400, 0x00FFD400), null, Shader.TileMode.CLAMP
        )
        val sweep = SweepGradient(
            cx, cy,
            intArrayOf(amber, yellow, 0xFFFFF0A0.toInt(), yellow, amber), null
        )
        sweep.setLocalMatrix(Matrix().apply { postRotate(-90f, cx, cy) })
        ringPaint.shader = sweep

        erx = radius * 0.46f
        ery = radius * 0.29f
        ecy = cy - radius * 0.30f
        signalPaint.shader = RadialGradient(
            cx, ecy, erx,
            intArrayOf(0xFFFFF3A0.toInt(), yellow, amber), floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        datePaint.textSize = radius * 0.07f
    }

    private fun refreshText(now: Long) {
        cal.timeZone = TimeZone.getDefault()
        cal.timeInMillis = now
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val minute = cal.get(Calendar.MINUTE)
        if (use24) {
            timeText = "%02d:%02d".format(hour, minute)
        } else {
            val h12 = if (hour % 12 == 0) 12 else hour % 12
            timeText = "%d:%02d".format(h12, minute)
        }
        val day = SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(Date(now))
        dateText = day.uppercase(Locale.getDefault()) +
            if (use24) "" else if (hour < 12) "  AM" else "  PM"
    }

    private fun drawHand(canvas: Canvas, angleDeg: Float, r1: Float, r2: Float, width: Float, color: Int) {
        canvas.save()
        canvas.rotate(angleDeg, cx, cy)
        handGlowPaint.strokeWidth = width * 2.4f
        canvas.drawLine(cx, cy - r1, cx, cy - r2, handGlowPaint)
        handPaint.strokeWidth = width
        handPaint.color = color
        canvas.drawLine(cx, cy - r1, cx, cy - r2, handPaint)
        canvas.restore()
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.currentTimeMillis()
        val t = (SystemClock.uptimeMillis() - t0) / 1000f

        val key = (now / 60000L) * 2 + (if (use24) 1 else 0)
        if (key != lastKey) {
            lastKey = key
            refreshText(now)
        }
        cal.timeInMillis = now
        val sec = cal.get(Calendar.SECOND)
        val secF = sec + cal.get(Calendar.MILLISECOND) / 1000f
        val minF = cal.get(Calendar.MINUTE) + secF / 60f
        val hourF = (cal.get(Calendar.HOUR_OF_DAY) % 12) + minF / 60f

        val breathe = 0.5f + 0.5f * sin(t * 1.2f)

        // ---- background + halo -------------------------------------------------------------
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        haloPaint.alpha = (90f + 80f * breathe).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, radius * 1.35f, haloPaint)

        // ---- 60 ticks, the current second is white ----------------------------------------
        val r1 = radius + strokeW * 1.05f
        for (i in 0 until 60) {
            val major = i % 5 == 0
            val current = i == sec
            val len = strokeW * (if (major) 0.95f else 0.5f) * (if (current) 1.5f else 1f)
            val a = Math.toRadians(-90.0 + i * 6.0)
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            if (current) {
                tickPaint.color = white
                tickPaint.alpha = 255
            } else {
                tickPaint.color = yellow
                tickPaint.alpha = if (major) 255 else 170
            }
            canvas.drawLine(
                cx + ca * r1, cy + sa * r1,
                cx + ca * (r1 + len), cy + sa * (r1 + len), tickPaint
            )
        }

        // ---- ring (full, glowing) ----------------------------------------------------------
        canvas.drawCircle(cx, cy, radius * 0.96f, discPaint)
        glowPaint.strokeWidth = strokeW * 2.6f
        glowPaint.alpha = 22
        canvas.drawCircle(cx, cy, radius, glowPaint)
        glowPaint.strokeWidth = strokeW * 1.8f
        glowPaint.alpha = 40
        canvas.drawCircle(cx, cy, radius, glowPaint)
        canvas.drawCircle(cx, cy, radius, ringPaint)

        // ---- hour + minute hands (kept in the outer band so the centre stays clear) ------
        drawHand(canvas, hourF * 30f, radius * 0.72f, radius * 0.90f, strokeW * 1.0f, white)
        drawHand(canvas, minF * 6f, radius * 0.72f, radius * 0.95f, strokeW * 0.6f, softYellow)

        // ---- second dot running around the ring --------------------------------------------
        val ha = Math.toRadians((secF * 6f - 90f).toDouble())
        val hx = cx + radius * cos(ha).toFloat()
        val hy = cy + radius * sin(ha).toFloat()
        dotPaint.color = yellow
        dotPaint.alpha = 80
        canvas.drawCircle(hx, hy, strokeW * (1.3f + 0.25f * breathe), dotPaint)
        dotPaint.color = white
        dotPaint.alpha = 255
        canvas.drawCircle(hx, hy, strokeW * 0.5f, dotPaint)

        // ---- Bat-Signal --------------------------------------------------------------------
        val hover = sin(t * 1.6f) * radius * 0.008f
        for (k in 3 downTo 1) {
            val grow = radius * 0.045f * k
            ovalRect.set(
                cx - erx - grow, ecy + hover - ery - grow,
                cx + erx + grow, ecy + hover + ery + grow
            )
            signalGlowPaint.alpha = ((14 - k * 3) + 18 * breathe).toInt().coerceIn(0, 255)
            canvas.drawOval(ovalRect, signalGlowPaint)
        }
        signalPaint.alpha = (225f + 30f * breathe).toInt().coerceIn(0, 255)
        canvas.save()
        canvas.translate(0f, hover)
        ovalRect.set(cx - erx, ecy - ery, cx + erx, ecy + ery)
        canvas.drawOval(ovalRect, signalPaint)
        val sc = (erx * 2f * 0.74f) / 184f
        shapeMatrix.reset()
        shapeMatrix.postTranslate(-100f, -52f)
        shapeMatrix.postScale(sc, sc)
        shapeMatrix.postTranslate(cx, ecy)
        batPath.transform(shapeMatrix, shapePath)
        canvas.drawPath(shapePath, logoPaint)
        canvas.restore()

        // ---- digital time + date -----------------------------------------------------------
        timePaint.textSize = radius * 0.38f
        val maxW = radius * 1.1f
        val w = timePaint.measureText(timeText)
        if (w > maxW) timePaint.textSize = timePaint.textSize * maxW / w
        canvas.drawText(timeText, cx, cy + radius * 0.36f, timePaint)

        datePaint.textSize = radius * 0.07f
        val dw = datePaint.measureText(dateText)
        val dMax = radius * 0.95f
        if (dw > dMax) datePaint.textSize = datePaint.textSize * dMax / dw
        canvas.drawText(dateText, cx, cy + radius * 0.55f, datePaint)

        postInvalidateOnAnimation()
    }
}
