package com.example.batclock

import android.app.Activity
import android.os.Bundle
import android.text.format.DateFormat
import android.view.View
import android.view.WindowManager
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var clock: ClockView
    private var toast: Toast? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences("bat_clock", MODE_PRIVATE)
        clock = findViewById(R.id.clock)
        clock.use24 = prefs.getBoolean("use24", DateFormat.is24HourFormat(this))

        // Tap the clock to switch between 12-hour and 24-hour digital time.
        clock.setOnClickListener {
            clock.use24 = !clock.use24
            prefs.edit().putBoolean("use24", clock.use24).apply()
            toast?.cancel()
            toast = Toast.makeText(
                this, if (clock.use24) "24-hour clock" else "12-hour clock", Toast.LENGTH_SHORT
            )
            toast?.show()
        }

        // Desk-clock behaviour: the screen stays on while the clock is open.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }
}
