package com.example.batclock

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/**
 * Home-screen clock widgets. The analog hands and the digital time are native system clock
 * views (AnalogClock + TextClock), so they keep ticking on their own without any service
 * or battery cost. Tapping a widget opens the app.
 */
abstract class ClockWidgetBase : AppWidgetProvider() {

    protected abstract val layoutRes: Int

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val rv = RemoteViews(ctx.packageName, layoutRes)
            rv.setOnClickPendingIntent(
                R.id.w_root,
                PendingIntent.getActivity(
                    ctx, 0, Intent(ctx, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            mgr.updateAppWidget(id, rv)
        }
    }
}

class ClockWidgetSmall : ClockWidgetBase() {
    override val layoutRes: Int = R.layout.widget_clock_small
}

class ClockWidgetLarge : ClockWidgetBase() {
    override val layoutRes: Int = R.layout.widget_clock_large
}
